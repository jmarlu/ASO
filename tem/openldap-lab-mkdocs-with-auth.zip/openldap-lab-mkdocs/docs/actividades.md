# 🧪 Actividades prácticas

Crear base/OU, usuarios, grupos, modificar atributos y backup.