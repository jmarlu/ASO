# 🐳 Laboratorio OpenLDAP en Docker

Arranque rápido y objetivos del laboratorio.