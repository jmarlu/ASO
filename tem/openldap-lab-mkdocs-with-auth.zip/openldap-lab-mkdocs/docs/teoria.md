# 📘 Teoría — Fundamentos de LDAP

Conceptos base: DIT, DN, clases de objeto, ACL.