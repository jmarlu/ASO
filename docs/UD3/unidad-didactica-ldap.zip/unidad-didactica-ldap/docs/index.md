# Unidad Didáctica: LDAP y OpenLDAP para ASIR

Bienvenido/a a la documentación del **Bloque 1 – Conceptos Fundamentales de LDAP**.  
Aquí encontrarás la **teoría ampliada con infografías y diagramas**, **actividades prácticas** y **soluciones**.

- Recomendado para: **ASIR / Administración de Sistemas Operativos**
- Objetivo: entender LDAP como **base de la gestión de identidades** y su papel en **OpenLDAP / AD / IAM**.

> Usa el menú lateral para acceder a **Teoría**, **Actividades** y **Soluciones**.